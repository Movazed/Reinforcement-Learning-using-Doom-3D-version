#ifndef __VIZDOOM_OBJECTS_DOCSTRINGS_H__
#define __VIZDOOM_OBJECTS_DOCSTRINGS_H__

namespace vizdoom {
namespace docstrings {
    
    const char *Mode = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *ScreenFormat = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *ScreenResolution = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *AutomapMode = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *Button = R"DOCSTRING(    )DOCSTRING";
    const char *GameVariable = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *SamplingRate = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *Label = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *Line = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *Sector = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *Object = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *ServerState = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *GameState = R"DOCSTRING(   TODO   )DOCSTRING";
    const char *DoomGame = R"DOCSTRING(   TODO   )DOCSTRING";

} // namespace docstrings
} // namespace vizdoom

#endif
