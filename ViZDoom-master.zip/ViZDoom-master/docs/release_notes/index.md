# Release Notes

```{eval-rst}
.. changelog::
    :github: https://github.com/Farama-Foundation/ViZDoom/releases
    :pypi: https://pypi.org/project/vizdoom/
    :changelog-url:
```
