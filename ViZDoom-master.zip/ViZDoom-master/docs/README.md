# ViZDoom documentation

This directory contains the documentation for ViZDOOm.

For more information about how to contribute to the documentation go to our [CONTRIBUTING.md](https://github.com/Farama-Foundation/Celshast/blob/main/CONTRIBUTING.md)

If you edit the C++ documentation (inside `api_cpp`), you need to run to update other files:
```
python scripts/create_python_docs_from_cpp_docs.py
python scripts/create_python_docstrings_from_cpp_docs.py
```
