# Gymnasium Env

```{eval-rst}
.. autoclass:: vizdoom.gymnasium_wrapper.base_gymnasium_env.VizdoomEnv
   :members:
```
